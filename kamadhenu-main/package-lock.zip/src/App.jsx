import React from 'react';
import { Routes, Route } from 'react-router-dom';
import Navbar from './components/Navbar';
import Home from './pages/Home';
import About from './pages/About';
import PoojaServices from './pages/PoojaServices';
import YagamServices from './pages/YagamServices';
import Gallery from './pages/Gallery';
import Contact from './pages/Contact';
import Footer from './components/Footer';
import { BookingProvider } from './context/BookingContext';
import './css/index.css';
import './css/App.css';

function App() {
  return (
    <BookingProvider>
      <div className="app">
        <Navbar />
        <main>
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/about" element={<About />} />
            <Route path="/pooja-services" element={<PoojaServices />} />
            <Route path="/yagam-services" element={<YagamServices />} />
            <Route path="/gallery" element={<Gallery />} />
            <Route path="/contact" element={<Contact />} />
          </Routes>
        </main>
        <Footer />
      </div>
    </BookingProvider>
  );
}

export default App;


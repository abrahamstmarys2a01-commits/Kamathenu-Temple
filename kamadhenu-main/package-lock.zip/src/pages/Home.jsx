import React from 'react';
import Hero from '../components/Hero';
import Services from '../components/Services';
import WhyChoose from '../components/WhyChoose';
import BookingSteps from '../components/BookingSteps';
import CTA from '../components/CTA';

const Home = () => {
  return (
    <>
      <Hero />
      <Services />
      <WhyChoose />
      <BookingSteps />
      <CTA />
    </>
  );
};

export default Home;

import React from 'react';
import Services from '../components/Services';
import BookingSteps from '../components/BookingSteps';

const PoojaServices = () => {
  return (
    <div className="page-wrapper animate-fade-up">
      <div className="section text-center pb-0">
        <div className="container">
          <h1 className="section-title">Divine Pooja Services</h1>
          <p className="hero-desc" style={{ margin: '1.5rem auto 0' }}>
            Explore our wide range of authentic poojas performed by expert priests.
          </p>
        </div>
      </div>
      <Services />
      <BookingSteps />
    </div>
  );
};

export default PoojaServices;

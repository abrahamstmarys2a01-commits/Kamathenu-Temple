import React from 'react';
import Card from './Card';
import Button from './Button';
import { Flame, Star, Heart, Coins, Sun, Calendar } from 'lucide-react';
import { useBooking } from '../context/BookingContext';

const Services = () => {
  const { openBooking } = useBooking();
  const services = [
    {
      icon: <Flame size={32} />,
      title: "Ganapathi Homam",
      description: "Remove obstacles and seek success in all endeavors by performing this sacred fire ritual."
    },
    {
      icon: <Star size={32} />,
      title: "Navagraha Homam",
      description: "Appease the nine planets and reduce their negative effects to bring harmony in life."
    },
    {
      icon: <Heart size={32} />,
      title: "Maha Mrityunjaya Homam",
      description: "A powerful pooja for longevity, health, and protection from life-threatening diseases."
    },
    {
      icon: <Coins size={32} />,
      title: "Lakshmi Kubera Pooja",
      description: "Attract wealth, prosperity, and financial stability by seeking blessings of Goddess Lakshmi."
    },
    {
      icon: <Sun size={32} />,
      title: "Sudarshana Homam",
      description: "Destroy negative energies, evil eyes, and protect your family with the power of Lord Vishnu."
    },
    {
      icon: <Calendar size={32} />,
      title: "Birthday / Nakshatra Pooja",
      description: "Special prayers on your birth star (Nakshatra) for a prosperous and happy year ahead."
    }
  ];

  return (
    <section className="section services" id="services">
      <div className="container">
        <div className="services-header text-center animate-fade-up">
          <span className="section-subtitle">Kamadhenu Temple</span>
          <h2 className="section-title">Poojas & Yagams</h2>
        </div>
        
        <div className="services-grid">
          {services.map((service, index) => (
            <Card 
              key={index}
              icon={service.icon}
              title={service.title}
              description={service.description}
            />
          ))}
        </div>
        
        <div className="text-center animate-fade-up" style={{ marginTop: '3rem' }}>
          <Button variant="outline" onClick={openBooking}>BOOK POOJA &amp; YAGAM</Button>
        </div>
      </div>
    </section>
  );
};

export default Services;

import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Menu, X } from 'lucide-react';
import Button from './Button';

const Navbar = () => {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const toggleMenu = () => {
    setIsMobileMenuOpen(!isMobileMenuOpen);
  };

  return (
    <nav className="navbar">
      <div className="container">
        <div className="logo">
          <Link to="/" style={{ textDecoration: 'none' }} onClick={() => setIsMobileMenuOpen(false)}>
            <h1 className="logo-title">KAMADHENU TEMPLE</h1>
            <span className="logo-subtitle">YAGAM & POOJA SEVA</span>
          </Link>
        </div>
        
        <div className={`nav-menu-wrapper ${isMobileMenuOpen ? 'open' : ''}`}>
          <ul className="nav-links">
            <li><Link to="/" className="nav-link" onClick={() => setIsMobileMenuOpen(false)}>Home</Link></li>
            <li><Link to="/about" className="nav-link" onClick={() => setIsMobileMenuOpen(false)}>About Us</Link></li>
            <li><Link to="/pooja-services" className="nav-link" onClick={() => setIsMobileMenuOpen(false)}>Pooja Services ▼</Link></li>
            <li><Link to="/yagam-services" className="nav-link" onClick={() => setIsMobileMenuOpen(false)}>Yagam Services ▼</Link></li>
            <li><Link to="/gallery" className="nav-link" onClick={() => setIsMobileMenuOpen(false)}>Gallery</Link></li>
            <li><Link to="/contact" className="nav-link" onClick={() => setIsMobileMenuOpen(false)}>Contact Us</Link></li>
          </ul>
          
          <div className="nav-action">
            <Link to="/pooja-services" onClick={() => setIsMobileMenuOpen(false)}>
              <Button variant="primary" className="btn-book">BOOK POOJA / YAGAM</Button>
            </Link>
          </div>
        </div>

        <button className="mobile-menu-btn" onClick={toggleMenu} aria-label="Toggle menu">
          {isMobileMenuOpen ? <X size={28} /> : <Menu size={28} />}
        </button>
      </div>
    </nav>
  );
};

export default Navbar;

import React from 'react';
import { Calendar, ArrowRight, Flame, Droplet, Star } from 'lucide-react';
import Button from './Button';
import { useBooking } from '../context/BookingContext';
import heroImage from '../assets/images/real_kamadhenu_cow.png';

const Hero = () => {
  const { openBooking } = useBooking();

  return (
    <section className="hero">
      <div className="container">
        <div className="hero-content animate-slide-left">
          <div className="hero-subtitle-wrapper">
            <span className="hero-subtitle">DIVINE BLESSINGS. POSITIVE ENERGY. PROSPEROUS LIFE.</span>
            <div className="hero-subtitle-line"></div>
          </div>
          <h1 className="hero-title">
            Perform Sacred Yagam &amp; <br/>
            Pooja at <span className="hero-highlight">Kamadhenu Temple</span>
          </h1>
          <p className="hero-desc">
            At Kamadhenu Temple, we perform powerful Vedic Yagams and Poojas to bring peace, prosperity, health and happiness into your life.
          </p>

          <div className="hero-features">
            <div className="hero-feature-item">
              <div className="hero-feature-icon-wrapper"><Flame size={18} /></div>
              <span>Vedic Rituals <br/>by Expert Priests</span>
            </div>
            <div className="hero-feature-item">
              <div className="hero-feature-icon-wrapper"><Droplet size={18} /></div>
              <span>Pure &amp; Authentic <br/>Temple Environment</span>
            </div>
            <div className="hero-feature-item">
              <div className="hero-feature-icon-wrapper"><Star size={18} /></div>
              <span>Blessings for You <br/>&amp; Your Family</span>
            </div>
          </div>

          <div className="hero-actions">
            <Button variant="primary" onClick={openBooking}>
              <Calendar size={16} /> BOOK POOJA / YAGAM
            </Button>
            {/* <Button variant="outline" className="btn-outline-custom">
              VIEW POOJA SERVICES <ArrowRight size={16} />
            </Button> */}
          </div>
        </div>

        <div className="hero-image-wrapper animate-slide-right">
          <div className="hero-image-bg"></div>
          <img src={heroImage} alt="Sacred Yagam and Pooja" className="hero-image" />
        </div>
      </div>
    </section>
  );
};

export default Hero;

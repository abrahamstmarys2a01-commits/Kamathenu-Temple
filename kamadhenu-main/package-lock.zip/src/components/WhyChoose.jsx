import React from 'react';
import { Award, Leaf, Settings, Globe } from 'lucide-react';

import ritualImage from '../assets/images/ritual_temple.png';

const WhyChoose = () => {
  const features = [
    {
      icon: <Award size={24} />,
      title: "Experienced Priests",
      desc: "Our priests are highly learned in Vedas and Agamas."
    },
    {
      icon: <Leaf size={24} />,
      title: "Pure & Sacred Environment",
      desc: "Authentic temple atmosphere for your rituals."
    },
    {
      icon: <Settings size={24} />,
      title: "Custom Poojas",
      desc: "Personalized poojas based on your astrological needs."
    },
    {
      icon: <Globe size={24} />,
      title: "Online Booking",
      desc: "Easy scheduling and remote participation available."
    }
  ];

  return (
    <section className="section why-choose">
      <div className="container">
        <div className="why-choose-left animate-slide-left">
          <img src={ritualImage} alt="Vedic Ritual" className="why-choose-image" />
        </div>
        
        <div className="why-choose-right animate-slide-right">
          <span className="section-subtitle">WHY CHOOSE US</span>
          <h2 className="section-title" style={{ marginBottom: '1rem' }}>
            Experience Divine.<br/>Feel the Difference.
          </h2>
          
          <div className="why-choose-features">
            {features.map((feature, index) => (
              <div className="feature-item" key={index}>
                <div className="feature-icon-wrapper">
                  {feature.icon}
                </div>
                <h4 className="feature-title">{feature.title}</h4>
                <p className="feature-desc">{feature.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default WhyChoose;

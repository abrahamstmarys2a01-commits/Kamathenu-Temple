import React from 'react';
import { Phone, Clock } from 'lucide-react';

const Header = () => {
  return (
    <div className="top-header">
      <div className="container">
        <div className="top-header-left">
          <span>|| Om Kamadhenuyai Namah ||</span>
        </div>
        <div className="top-header-right">
          <div className="top-header-item">
            <Phone size={14} />
            <span>Call Us: +91 98765 43210</span>
          </div>
          <div className="top-header-item">
            <Clock size={14} />
            <span>Timings: 6:00 AM – 8:00 PM</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Header;

import React from 'react';
import { MapPin, Phone, Mail, Clock } from 'lucide-react';
import Button from './Button';

const Footer = () => {
  return (
    <footer className="footer">
      <div className="container">
        <div className="footer-grid">
          {/* Column 1 */}
          <div className="footer-col">
            <div className="logo footer-logo">
              <h2 className="logo-title">KAMADHENU TEMPLE</h2>
            </div>
            <p className="footer-desc">
              Experience the divine presence. We perform authentic Vedic rituals for your peace, prosperity, and spiritual growth.
            </p>
            <div className="social-links">
              <a href="#" className="social-link">FB</a>
              <a href="#" className="social-link">TW</a>
              <a href="#" className="social-link">IG</a>
              <a href="#" className="social-link">YT</a>
            </div>
          </div>
          
          {/* Column 2 */}
          <div className="footer-col">
            <h3 className="footer-title">Quick Links</h3>
            <div className="footer-links">
              <a href="#" className="footer-link">Home</a>
              <a href="#" className="footer-link">About Us</a>
              <a href="#" className="footer-link">Pooja Services</a>
              <a href="#" className="footer-link">Yagam Services</a>
              <a href="#" className="footer-link">Gallery</a>
              <a href="#" className="footer-link">Contact Us</a>
            </div>
          </div>
          
          {/* Column 3 */}
          <div className="footer-col">
            <h3 className="footer-title">Contact Us</h3>
            <div className="contact-info">
              <div className="contact-item">
                <Phone size={18} />
                <span>+91 98765 43210</span>
              </div>
              <div className="contact-item">
                <Mail size={18} />
                <span>info@kamadhenutemple.com</span>
              </div>
              <div className="contact-item">
                <MapPin size={18} />
                <span>123 Divine Street, Spiritual City, SC 456789</span>
              </div>
              <div className="contact-item">
                <Clock size={18} />
                <span>Temple Timing: 6:00 AM – 8:00 PM</span>
              </div>
            </div>
          </div>
          
          {/* Column 4 */}
          <div className="footer-col">
            <h3 className="footer-title">Newsletter</h3>
            <p className="footer-desc" style={{ marginTop: 0 }}>
              Subscribe to our newsletter for updates on special poojas and temple events.
            </p>
            <form className="newsletter-form" onSubmit={(e) => e.preventDefault()}>
              <input type="email" placeholder="Your Email Address" className="newsletter-input" required />
              <Button variant="primary">Subscribe Now</Button>
            </form>
          </div>
        </div>
        
        <div className="footer-bottom">
          <p>© 2026 Kamadhenu Temple. All Rights Reserved.</p>
          <div className="footer-bottom-links">
            <a href="#" className="footer-link">Privacy Policy</a>
            <a href="#" className="footer-link">Terms & Conditions</a>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;

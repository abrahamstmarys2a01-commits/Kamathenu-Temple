import React from 'react';
import { ArrowRight } from 'lucide-react';
import { useBooking } from '../context/BookingContext';

const Card = ({ icon, title, description, linkText = 'Book Now' }) => {
  const { openBooking } = useBooking();

  return (
    <div className="card animate-fade-up">
      <div className="card-icon">
        {icon}
      </div>
      <h3 className="card-title">{title}</h3>
      <p className="card-desc">{description}</p>
      <button className="card-link" onClick={openBooking}>
        {linkText} <ArrowRight size={16} />
      </button>
    </div>
  );
};

export default Card;
